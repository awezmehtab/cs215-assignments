## CS215 Assignments
This repository contains all our work/code for our course CS215 - Data Analysis and Interpretation. If you want to add your answers try not to add/delete new files. Add your answer to question i in A1/qi.tex and compile the whole tex document. Use the instructions for typing answers as it's given.
